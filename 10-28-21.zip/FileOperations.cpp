#include "Header.h"
#include <fstream>
#include <iostream>
using namespace std;

FileOperations::FileOperations() {

}

void FileOperations::Save2FileP(player& p) {
	cout << "Which file would you like to save to?";
	cin >> P_file_name;
	p_myFile.open(P_file_name);
	if (p_myFile.fail()) {
		cerr << "Player file could not be opened";
		exit(1);
	}

	p_myFile << p.getMaxHP() << "\n";
	p_myFile << p.getHP() << "\n";
	cout << p.getHP();
	p_myFile << p.getDMG() << "\n";
	p_myFile << p.getDurability() << "\n";
	return;

}

void FileOperations::Save2FileS(scoreboard& s) {

	SB_myFile.open(SB_file_name);
	if (SB_myFile.fail()) {
		cerr << "Scoreboard file could not be opened";
		exit(1);
	}

	SB_myFile << "Name: " << s.getName() << "\n";
	SB_myFile << "Score: " << s.getScore() << "\n";
	SB_myFile << s.getDiff() << "\n";
	SB_myFile << s.getDiff() << "\n";
	SB_myFile << s.getFloor() << "\n";

	if (sortedScores.size() == 0 && sortedNames.size() == 0) {
		sortedScores.push_back(s.getScore());
		sortedNames.push_back(s.getName());
	}
	else {
		for (int i = 0; i < sortedScores.size(); i++) {
			if (s.getScore() < sortedScores[i]) {
				;
			}
			else {
				sortedScores.insert(sortedScores.begin() + i, s.getScore());
				sortedNames.insert(sortedNames.begin() + i, s.getName());
			}
		}
	}
	return;

}

void FileOperations::ChooseFile(scoreboard& s, player& p) {
	char oper;
	string name;
	ifstream file1;
	ifstream file2;
	cout << "Do you have an existing file?" << endl << "[Y]es or [N]o" << endl;
	cin >> oper;
	if (oper == 'n' || oper == 'N') {
		cout << "What would you like to call this file?" << endl;
		cin >> name;
		file1.open(name);
		cout << "New file successfully created." << endl;
		file2.open("scoreboard,txt");
		if (file2.fail())
		{
			cerr << "File cannot be opened." << endl;
			exit(1);
		}
	}
	else if (oper == 'y' || oper == 'Y') {
		cout << "Which existing file would you like to choose?" << endl;
		cin >> name;
		file1.open(name);
		if (file1.fail()) {
			cerr << "This file does not exist." << endl;
		}
		while (!file1.eof()) {
			string name;
			file1 >> name;
			p.setName(name);
			int maxH;
			file1 >> maxH;
			p.setMaxHP(maxH);
			int curHP;
			file1 >> curHP;
			p.setHP(curHP);
			int dmg;
			file1 >> dmg;
			p.setDMG(dmg);
			int dur;
			file1 >> dur;
			p.setDurability(dur);
		}
		file2.open("scoreboard.txt");
		if (file2.fail())
		{
			cerr << "File cannot be opened." << endl;
			exit(1);
		}
		int currentScore = 0;
		string currentDif = "";
		int difMod = 0;
		int currentFloor = 0;
		while (!file2.eof()) {
			file2 >> currentScore;
			file2 >> currentDif;
			file2 >> difMod;
			file2 >> currentFloor;
		}
		s.setScore(currentScore);
		s.setDiff(currentDif);
		s.setDiffMod(difMod);
		s.setFloor(currentFloor);
	}
}

void FileOperations::CloseFile() {
	SB_myFile.close();
	p_myFile.close();
}

void FileOperations::ScoreRank() {
	for (int i = 0; i < sortedScores.size(); i++) {
		cout << "Player: " << sortedNames[i] << endl;
		cout << "Score: " << sortedScores[i] << endl;
	}
}
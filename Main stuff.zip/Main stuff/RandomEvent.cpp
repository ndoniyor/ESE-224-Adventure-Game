#include "Header.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

void RandomEvent::getEvent(player& p, scoreboard& s) {
    srand(time(NULL));
    int event = rand() % 100;
    if (event < 20) {
        int pick = 0;
        cout << "You come across three chests which do you open? (1, 2, or 3)" << endl;
        cin >> pick;
        if (pick == 1) {
            cout << "The chest is rife with riches you gain (400 points)" << endl;
            s.AddScore(400);
            return;
        }
        if (pick == 2) {
            cout << "The has a decent amount of treasure you (gain 200 points)" << endl;
            s.AddScore(200);
            return;
        }
        if (pick == 3) {
            cout << "The chest is empty but could still fetch some gold for the wood (gain 50 points)" << endl;
            s.AddScore(50);
            return;
        }
        else {
            cout << "Invalid input, you are unable to overcome your indecision and move on" << endl;
            return;
        }
    }
    if (event > 19 && event < 40) {
        char pick = ' ';
        cout << "You see some gold burried in a pile of rusted weapons, do you try to grab it?(y/n)" << endl;
        cin >> pick;
        int event2 = rand() % 100;
        if (pick == 'y') {
            if (event2 > 49) {
                cout << "You sucessfully extract the gold (gain 400 points)" << endl;
                s.AddScore(400);
                return;
            }
            if (event < 49) {
                cout << "You cut yourself on the sword and fail to get the gold (lose 1 hp)" << endl;
                p.setHP(p.getHP() - 1);
                return;
            }
        }
        if (pick == 'n') {
            cout << "You move on, grabbing a coin you find at your feet (gain 5 points)" << endl;
            s.AddScore(5);
            return;
        }
        else {
            cout << "Invalid input, you are unable to overcome your indecision and move on" << endl;
            return;
        }

    }
    if (event > 39 && event < 60) {
        char pick = ' ';
        cout << "You happen across table with a mysterious coin, it urges you to flip it. You see the word tails scratched into the table. Flip it? (y/n)" << endl;
        cin >> pick;
        if (pick == 'y') {
            int flip = rand() % 100;
            if (flip > 44) {
                cout << "Heads, you feel a mysterious pain (lose 1 hp)" << endl;
                p.setHP(p.getHP() - 1);
                return;
            }
            if (flip < 44) {
                cout << "Tails, the coin vanishes and a sack of gold appears (gain 200 points)" << endl;
                s.AddScore(200);
                return;
            }
        }
        if (pick == 'n') {
            cout << "You pocket the coin and move on." << endl;
            return;
        }
        else {
            cout << "Invalid input, you are unable to overcome your indecision and move on" << endl;
            return;
        }

    }
    if (event > 59 && event < 80) {
        char pick = ' ';
        cout << "You see a giant golden helmet, do you try to take it with you? (y/n)" << endl;
        cin >> pick;
        if (pick == 'y') {
            int event2 = rand() % 100;
            if (event2 > 44) {
                cout << "You try to pick up the helmet but it is too heavy (lose 1 hp)" << endl;
                p.setHP(p.getHP() - 1);
                return;
            }
            if (event2 < 44) {
                cout << "You pick up the helmet without injuring yourself, arm day has paid off (gain 500 points)" << endl;
                s.AddScore(500);
                return;
            }
        }
        if (pick == 'n') {
            cout << "You dont try to pick it up, you feel condfident in your decision and your current helmet (gain 2 hp)" << endl;
            p.setHP(p.getHP() + 2);
            return;
        }
        else {
            cout << "Invalid input, you are unable to overcome your indecision and move on" << endl;
            return;
        }
    }
    if (event > 79) {
        char pick = ' ';
        cout << "You come across a mysterious potion, do you drink it? (y/n)" << endl;
        cin >> pick;
        if (pick == 'y' || pick == 'Y') {
            int event2 = rand() % 100;
            if (event2 > 44) {
                cout << "You drink the potion and feel sick (lose 1 hp)" << endl;
                p.setHP(p.getHP() - 1);
                return;
            }
            if (event2 < 44) {
                cout << "You drink the potion and feel stronger (gain 5 hp)" << endl;
                p.setHP(p.getHP() + 5);
                return;
            }
        }
        if (pick == 'n' || pick == 'N') {
            cout << "You take the potion to sell later (gain 100 points)" << endl;
            s.AddScore(100);
            return;
        }
        else {
            cout << "Invalid input, you are unable to overcome your indecision and move on" << endl;
            return;
        }
    }
}